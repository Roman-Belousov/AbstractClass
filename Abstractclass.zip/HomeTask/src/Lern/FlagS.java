package Lern;

public class FlagS extends Choice {
	public FlagS() {
		super("Сортировка по символу $");
	}

	@Override
	public void compare(String a[]) {
		String template = "$";
		int index = 0;
		for (int i = 0; i < a.length; i++) {
			if (a[i].contains(template)) {
				index++;
				if (index <= 3) {
					System.out.println(a[i]);
				}
			}
		}
	}
}
