package Lern;

public class Simbol extends Choice {
	public Simbol() {
		super("Сортировка по символу -=> ");
	}

	@Override
	public void compare(String a[]) {
		String template = "-=>";

		for (int i = 0; i < a.length; i++) {
			if (a[i].contains(template)) {

				System.out.println(a[i]);
			}
		}
	}
}
