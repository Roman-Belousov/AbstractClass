package Lern;

public class Smile extends Choice {

	public Smile() {
		super("Сортировка по смайлику");
	}

	@Override
	public void compare(String a[]) {
		String template = ":)";
		String template1 = ";)";
		for (int i = 0; i < a.length; i++) {
			if (a[i].contains(template)) {
				System.out.println(a[i]);
			} else if (a[i].contains(template1))
				System.out.println(a[i]);
		}

	}
}
