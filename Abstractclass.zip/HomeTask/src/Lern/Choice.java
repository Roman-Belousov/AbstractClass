package Lern;

abstract public class Choice {
	private String name;

	public Choice(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	abstract public  void compare(String a[]);
}
