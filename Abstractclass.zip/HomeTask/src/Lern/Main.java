package Lern;

import java.util.Scanner;

public class Main {
	public static void output(String a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.printf("%s \n ", a[i]);
		}
		System.out.println();
	}

	public static void main(String[] args) {
		Choice choices[] = { new StringLength(), new FlagS(), new Simbol(), new Smile() };
		System.out.println("Исходный массив:");
		String[] a = Generator.generate();
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("Выберите способ сортировки:");
			for (int i = 0; i < choices.length; i++) {
				System.out.printf("%d) %s\n", i + 1, choices[i].getName());
			}
			System.out.printf("%d) Выход\n", choices.length + 1);
			System.out.print("Сделайте выбор: ");
			int index = scanner.nextInt() - 1;
			if (index == choices.length) {
				System.out.println("До свидания");
				scanner.close();
				break;

			}
			System.out.println("Отсортированный массив:");

			if (index == 0) {
				StringLength stringlength = new StringLength();
				stringlength.compare(a);
			} else if (index == 1) {
				FlagS flags = new FlagS();
				flags.compare(a);
			} else if (index == 2) {
				Simbol simbol = new Simbol();
				simbol.compare(a);
			} else if (index == 3) {
				Smile smile = new Smile();
				smile.compare(a);

			}

		}

	}

}
