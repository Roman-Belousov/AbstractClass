package Lern;

public class StringLength extends Choice {
	public StringLength() {
		super("Сортировка по длине строки");
	}

	@Override
	public void compare(String a[]) {

		for (int i = 0; i < a.length; i++) {
			String s = a[i];

			if (s.length() > 9) {
				System.out.println(s);
			}
		}
	}
}
